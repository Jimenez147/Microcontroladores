#include <stdio.h>
#include <math.h>
#include <string.h>
#include "esp_log.h"
#include "driver/i2c.h"
#include "i2c-lcd.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/adc.h"
#include "esp_adc/adc_oneshot.h"
#include "esp_task_wdt.h"

adc1_channel_t in = ADC1_CHANNEL_6; // Pin de ADC que sera usado

const float adc_constant = 0.0046875; // Factor de conversion del ADC
const int size = 100;                 // Cantidad de muestras de voltajes para el calculo

void adc_init(void) // Se inicia el pin del ADC
{
    ESP_ERROR_CHECK(adc1_config_width(ADC_WIDTH_BIT_12));
    ESP_ERROR_CHECK(adc1_config_channel_atten(in, ADC_ATTEN_DB_12));
}
static esp_err_t i2c_master_init(void) // Se inicia el i2c para utilizar la LCD
{
    int i2c_master_port = I2C_NUM_0;

    i2c_config_t conf = {
        .mode = I2C_MODE_MASTER,
        .sda_io_num = GPIO_NUM_21,
        .scl_io_num = GPIO_NUM_22,
        .sda_pullup_en = GPIO_PULLUP_ENABLE,
        .scl_pullup_en = GPIO_PULLUP_ENABLE,
        .master.clk_speed = 100000,
    };

    i2c_param_config(i2c_master_port, &conf);

    return i2c_driver_install(i2c_master_port, conf.mode, 0, 0, 0);
}
static esp_err_t wdt_init(void) // Se inicia el watchdog
{
    esp_task_wdt_deinit();
    esp_task_wdt_config_t wdt_config = {
        .timeout_ms = 1000,
        .idle_core_mask = 0,
        .trigger_panic = false};

    return esp_task_wdt_init(&wdt_config);
}
void send_lcd(char out[], bool en) // Se envian los datos a la LCD
{
    lcd_init();
    lcd_clear();
    lcd_put_cur(0, 0);
    lcd_send_string("   Voltmeter");
    lcd_put_cur(1, 0);
    if (en)
    {
        lcd_send_string(out);
        puts(out);
    }
    else
    {
        lcd_send_string("No Voltage Imput");
    }
}

void app_main(void)
{
    float muestra[size] = {};
    float ress = 0, cache, sum = 0;
    char out[15] = {};
    int count = 0;
    bool en;

    adc_init();
    ESP_ERROR_CHECK(i2c_master_init());
    ESP_ERROR_CHECK(wdt_init());
    esp_task_wdt_add(NULL);

    while (true)
    {
        muestra[count] = (adc1_get_raw(in) * adc_constant); // Se almacenan las muestras tomadas del ADC en un arreglo
        count++;
        if (count == size) // Cuando se tienen todas la muestras se realiza el calculo
        {
            cache = ress; // Se almacena una version anterior de la medida
            sum = 0;
            count = 0;
            for (int i = 0; i < size; i++) // Se hace el calculo
            {
                muestra[i] *= muestra[i];
                sum += muestra[i];
            }
            ress = sqrt(sum / 100);
            ress = round(ress * 10) / 10;   // Se redondea el resultado a una cifra decimal
            en = (ress < 1) ? false : true; // Se determina si hay entrada de voltaje
            if (ress != cache)              // Solo se actualizan los valores de la LCD cuando hay un cambio en la medida
            {
                sprintf(out, "    %.1f V", ress);
                send_lcd(out, en);
            }
            ESP_ERROR_CHECK_WITHOUT_ABORT(esp_task_wdt_reset());
        }
        vTaskDelay(1 / portTICK_PERIOD_MS);
    }
}
